/* Copyright 2021 DucaPowr Team */
#pragma once

#define DEBUG_FILE_NAME "duca.debug"
