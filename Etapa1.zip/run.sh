#!/bin/bash
cd src
xboard -fcp "make run" -debug